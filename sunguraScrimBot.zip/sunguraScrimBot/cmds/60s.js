

module.exports.run = async (bot,message,args) => {

    message.channel.send("Next scrim in 1 minute, Tab-in <@&541675419821146122>");


}

module.exports.help = {
    name: "60s"
}