const fs = require('fs');

module.exports.run = async (bot, message, args) => {

    if (args.length === 0){
        message.channel.send("A channel is needed after the command ex: `add-channel #scrim-codes");
    }else if (args.length > 0){
        let channels_raw = fs.readFileSync('./channel.json');
        let channels_array = JSON.parse(channels_raw);

        let channel = args[0];
        let found = false;

        for (var i = 0; i < channels_array.channels.length; i++){
            if (channel === channels_array.channels[i]){
                found === true;
                message.channel.send(channel + " already present in allowed channels");
                return;;
            }
        }

        if (!found){
            channels_array.channels.push(channel);
            let channels_write = JSON.stringify(channels_array);
            fs.writeFileSync('./channel.json', channels_write);
        }
    }


}

module.exports.help = {
    name: "add-channel"
}