

module.exports.run = async (bot,message,args) => {

    message.channel.send("Next Scrim Starting Soon, Join the voice channel <@&541675419821146122>");


}

module.exports.help = {
    name: "soon"
}